import { DesignModel } from "../runtime/designRuntime.js";

class Component extends DesignModel {
  renderVals() {
    const LC = '#ff6f61';

    const ICONS = {
      agency: ['M8.6 9.6a2.6 2.6 0 1 0 0-5.2 2.6 2.6 0 0 0 0 5.2zM16.4 9.6a2.6 2.6 0 1 0 0-5.2 2.6 2.6 0 0 0 0 5.2z', 'M3.4 19.8v-1.2a4.4 4.4 0 0 1 4.4-4.4h1.6a4.4 4.4 0 0 1 4.4 4.4v1.2M14.8 14.2h1.4a4.4 4.4 0 0 1 4.4 4.4v1.2'],
      hall: ['M4.8 20.4v-9.6L12 5.2l7.2 5.6v9.6', 'M2.8 20.4h18.4M9.4 20.4v-4.4a2.6 2.6 0 0 1 5.2 0v4.4M12 2.6v2.6'],
      studio: ['M4.6 8.2h2.6L8.6 5.8h6.8l1.4 2.4h2.6a1.8 1.8 0 0 1 1.8 1.8v7.6a1.8 1.8 0 0 1-1.8 1.8H4.6a1.8 1.8 0 0 1-1.8-1.8V10a1.8 1.8 0 0 1 1.8-1.8z', 'M12 16.6a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4z'],
      dress: ['M10 3.6h4l-.8 3.2 4.6 9.6a1.8 1.8 0 0 1-1 2.5 13.6 13.6 0 0 1-9.6 0 1.8 1.8 0 0 1-1-2.5l4.6-9.6z', 'M10.8 6.8h2.4'],
      makeup: ['M15.4 3.8a2.2 2.2 0 0 1 3.1 3.1l-1.3 1.3-3.1-3.1z', 'M14.1 5.1 5.2 14a2 2 0 0 0-.5.9l-.9 4.1a.7.7 0 0 0 .9.9l4.1-.9a2 2 0 0 0 .9-.5l8.9-8.9'],
      snap: ['M8.4 3.6h10a1.8 1.8 0 0 1 1.8 1.8v10a1.8 1.8 0 0 1-1.8 1.8h-10a1.8 1.8 0 0 1-1.8-1.8v-10a1.8 1.8 0 0 1 1.8-1.8z', 'm7 14.4 3.4-3.4 2.4 2.4 2.4-2.4 4.6 4.6M3.4 7v12a1.6 1.6 0 0 0 1.6 1.6h12'],
      ring: ['M12 20.6a5.6 5.6 0 1 0 0-11.2 5.6 5.6 0 0 0 0 11.2z', 'm9.6 6.4 2.4-2.8 2.4 2.8-2.4 3z'],
      honeymoon: ['M12 3.6c1.1 0 2 1.5 2 3.4v2.4l6.4 3.8v2.2L14 13.6v3.6l2.4 1.6v1.6L12 19.4l-4.4 1v-1.6L10 17.2v-3.6l-6.4 2.2v-2.2L10 9.4V7c0-1.9.9-3.4 2-3.4z', 'M12 6.8v2.4'],
      hair: ['M7 6.4a2.4 2.4 0 1 0 0 4.8 2.4 2.4 0 0 0 0-4.8zM7 12.8a2.4 2.4 0 1 0 0 4.8 2.4 2.4 0 0 0 0-4.8z', 'm9.2 10.4 10.4-5.8M9.2 13.6l10.4 5.8'],
      bouquet: ['M12 7.6a2.2 2.2 0 1 0 0-4.4 2.2 2.2 0 0 0 0 4.4zM7 10.2a2.2 2.2 0 1 0 0-4.4 2.2 2.2 0 0 0 0 4.4zM17 10.2a2.2 2.2 0 1 0 0-4.4 2.2 2.2 0 0 0 0 4.4z', 'M8.4 9.6 12 20.4M15.6 9.6 12 20.4M12 9.8v10.6M9.4 20.6h5.2'],
      invite: ['M4.4 5.8h15.2a1.8 1.8 0 0 1 1.8 1.8v9a1.8 1.8 0 0 1-1.8 1.8H4.4a1.8 1.8 0 0 1-1.8-1.8v-9a1.8 1.8 0 0 1 1.8-1.8z', 'm2.9 6.8 9.1 6.2 9.1-6.2'],
      home: ['M5 11V8.6a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2V11', 'M3 12.8a1.8 1.8 0 0 1 3.6 0V16h10.8v-3.2a1.8 1.8 0 0 1 3.6 0V19H3z']
    };

    // 온보딩 3/5에서 «아직»으로 남은 업종만 순회한다. 이미 결정한 업종은 빼고 돈다.
    const CATS = [
      ['웨딩홀', 'hall'],
      ['스튜디오', 'studio'], ['드레스', 'dress'], ['메이크업', 'makeup'], ['헤어변형', 'hair'],
      ['본식스냅', 'snap'], ['부케', 'bouquet'], ['청첩장', 'invite'],
      ['예물', 'ring'], ['혼수', 'home'], ['허니문', 'honeymoon']
    ];
    const DONE = ['웨딩홀'];
    const ORDER = CATS.filter(([n]) => !DONE.includes(n));
    const ALL = CATS;
    const STEP = 620;
    const CYCLE = ORDER.length * STEP;

    const cats = ORDER.map(([name, key], i) => ({
      name,
      d1: ICONS[key][0], d2: ICONS[key][1],
      iconWrap: 'position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:34px;height:34px;display:flex;align-items:center;justify-content:center;'
        + 'animation:wpSwap' + ORDER.length + ' ' + CYCLE + 'ms linear ' + (i * STEP) + 'ms infinite;opacity:' + (i === 0 ? 1 : 0)
    }));

    const allCats = ALL.map(([name, key]) => ({ name, d1: ICONS[key][0], d2: ICONS[key][1] }));

    const step = (name, state) => ({
      name,
      row: 'display:flex;align-items:center;gap:10px;min-height:30px',
      dot: state === 'now'
        ? 'width:18px;height:18px;flex:0 0 18px;border-radius:999px;background:' + LC
        : state === 'done'
          ? 'width:18px;height:18px;flex:0 0 18px;border-radius:999px;background:' + LC + ';display:flex;align-items:center;justify-content:center'
          : 'width:18px;height:18px;flex:0 0 18px;border-radius:999px;background:#eaebee',
      label: 'font-size:16px;line-height:22px;color:' + (state === 'todo' ? '#adb1ba' : '#212124')
        + (state === 'now' ? ';font-weight:700' : ''),
      done: state === 'done'
    });

    const FAST = 820;
    const FCYCLE = ORDER.length * FAST;
    const spin = (px, label, spec) => ({
      label, spec,
      box: 'position:relative;width:' + (px + 20) + 'px;height:' + (px + 20) + 'px;border-radius:'
        + (px >= 40 ? 14 : px >= 28 ? 12 : 10) + 'px;background:#fff;box-shadow:inset 0 0 0 1px #eaebee;display:flex;align-items:center;justify-content:center',
      items: ORDER.map(([, key], i) => ({
        px, d1: ICONS[key][0], d2: ICONS[key][1],
        wrap: 'position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);display:flex;'
          + 'animation:wpSwap' + ORDER.length + ' ' + FCYCLE + 'ms linear ' + (i * FAST) + 'ms infinite;opacity:' + (i === 0 ? 1 : 0)
      })),
      style: 'width:' + px + 'px;height:' + px + 'px'
        + ';animation:wpSpin 900ms linear infinite'
    });

    const sk = (a, b) => ({
      a: 'height:16px;border-radius:4px;background:#eaebee;width:' + a + ';animation:wpSk 1400ms ease-in-out infinite',
      b: 'height:13px;border-radius:4px;background:#f2f3f6;width:' + b + ';animation:wpSk 1400ms ease-in-out infinite'
    });

    const use = (when, what, copy, kind) => ({
      when, what, copy,
      whatStyle: 'width:200px;flex:0 0 200px;font-size:16px;line-height:24px;font-weight:700;color:'
        + (kind === 'brand' ? LC : kind === 'no' ? '#e81607' : '#212124')
    });


    const C = '#ff6f61';
    const ring = (px, w) => 'width:' + px + 'px;height:' + px + 'px;flex:0 0 ' + px + 'px;border-radius:999px;border:' + w + 'px solid #eaebee;border-top-color:' + C + ';animation:wpSpin 800ms linear infinite';


    const eP = '#ff6f61';
    const eINK = '#212124';
    const eSUB = '#4d5159';
    const eMUTED = '#868b94';
    const eDIM = '#adb1ba';
    const eSEC = '#f2f3f6';
    const eREC = '#f7f8fa';
    const eBORDER = '#eaebee';
    const eGREEN = '#1aa174';
    const eDS = 'assets/seed-icons/';
    const eICO = (n, sz, c) => 'display:inline-block;width:' + sz + 'px;height:' + sz + 'px;flex:0 0 ' + sz + 'px;background-color:' + c
      + ';-webkit-mask:url(' + eDS + n + '.svg) center/contain no-repeat;mask:url(' + eDS + n + '.svg) center/contain no-repeat';
    const eGLYPH = (sz, bg, stroke, path) => 'width:' + sz + 'px;height:' + sz + 'px;flex:0 0 ' + sz + 'px;border-radius:999px;background-color:' + bg
      + ';background-image:url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'' + stroke + '\' stroke-width=\'2.8\' stroke-linecap=\'round\' stroke-linejoin=\'round\'%3E' + path + '%3C/svg%3E");background-size:' + Math.round(sz * 0.48) + 'px;background-position:center;background-repeat:no-repeat';
    const eCHK = (sz, bg, stroke) => eGLYPH(sz, bg, stroke, '%3Cpath d=\'m5 12.5 4.5 4.5L19 7.5\'/%3E');

    const FILLED = ['home', 'search', 'heart', 'profile'];
    const tab = (icon, text, on) => ({ icon: eICO(on && FILLED.indexOf(icon) >= 0 ? icon + '-fill' : icon, 24, on ? eINK : eMUTED), text,
      label: 'font-size:12px;line-height:16px;font-weight:700;color:' + (on ? eINK : eMUTED) });
    const bar = a => [tab('home', '홈', a === 'home'), tab('search', '검색', a === 'search'), tab('heart', 'Pick', a === 'pick'), tab('calendar', '웨딩노트', a === 'note'), tab('profile', 'MY', a === 'my')];

    const empt = (title, emptyT, emptyS, cta, more) => ({ title, empty: true, emptyT, emptyS, cta: cta || '', more: more || '',
      ctaStyle: 'margin-top:12px;height:44px;padding:0 18px;border-radius:8px;background:' + eP + ';color:#fff;display:inline-flex;align-items:center;font-size:15px;font-weight:700' });
    const data = (title, rows, more) => ({ title, empty: false, rows, more: more || '' });

    const esc = (o) => ({
      code: o.code, title: o.title, desc: o.desc,
      nav: o.nav || '', back: o.back !== false,
      navStyle: 'flex:1;min-width:0;text-align:' + (o.back === false ? 'left' : 'center') + ';font-size:' + (o.back === false ? '26px' : '16px') + ';font-weight:700;color:' + eINK,
      sections: (o.sections || []).map(c => Object.assign({}, c, {
        wrapStyle: (o.sections || []).length === 1
          ? 'flex:1;min-height:0;padding:0 20px 24px;display:flex;flex-direction:column;gap:12px'
          : 'flex:0 0 auto;padding:0 20px 24px;display:flex;flex-direction:column;gap:12px',
        bodyStyle: (o.sections || []).length === 1
          ? 'flex:1;min-height:0;display:flex;flex-direction:column;justify-content:center'
          : 'display:flex;flex-direction:column'
      })),
      done: !!o.doneT, doneT: o.doneT || '', doneS: o.doneS || '',
      markStyle: o.mark === 'ok' ? eCHK(64, '#e8faf6', '%231aa174') : eCHK(64, '#fff5f2', '%23ff6f61'),
      items: o.items || null, nextCard: o.nextCard || '',
      dock: o.dock || '', dock2: o.dock2 || '',
      dockStyle: 'flex:' + (o.dock2 ? '1.4' : '1') + ';height:56px;border-radius:6px;background:' + eP + ';color:#fff;display:flex;align-items:center;justify-content:center;font-size:17px;font-weight:700',
      tabs: o.tabs ? bar(o.tabs) : null
    });

    const rl = (k, v) => ({ k, v });
    const cp = (w, t, s) => ({ w, t, s });


    const P = '#ff6f61';
    const INK = '#212124';
    const SUB = '#4d5159';
    const MUTED = '#868b94';
    const DIM = '#adb1ba';
    const SEC = '#f2f3f6';
    const REC = '#f7f8fa';
    const BORDER = '#eaebee';
    const RED = '#ff4133';
    const GREEN = '#1aa174';
    const AMBER = '#805217';
    const DS = 'assets/seed-icons/';
    const ICO = (n, sz, c) => 'display:inline-block;width:' + sz + 'px;height:' + sz + 'px;flex:0 0 ' + sz + 'px;background-color:' + c
      + ';-webkit-mask:url(' + DS + n + '.svg) center/contain no-repeat;mask:url(' + DS + n + '.svg) center/contain no-repeat';
    const GLYPH = (sz, bg, stroke, path) => 'width:' + sz + 'px;height:' + sz + 'px;flex:0 0 ' + sz + 'px;border-radius:999px;background-color:' + bg
      + ';background-image:url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'' + stroke + '\' stroke-width=\'2.6\' stroke-linecap=\'round\' stroke-linejoin=\'round\'%3E' + path + '%3C/svg%3E");background-size:' + Math.round(sz * 0.5) + 'px;background-position:center;background-repeat:no-repeat';
    const CHK = (sz, bg, stroke) => GLYPH(sz, bg, stroke, '%3Cpath d=\'m5 12.5 4.5 4.5L19 7.5\'/%3E');
    const BANG = (sz, bg, stroke) => GLYPH(sz, bg, stroke, '%3Cpath d=\'M12 7v6\'/%3E%3Cpath d=\'M12 17h.01\'/%3E');

    const SHEET = 'position:absolute;left:0;right:0;bottom:0;background:#fff;border-radius:20px 20px 0 0;padding:14px 24px 28px;display:flex;flex-direction:column;gap:12px;box-sizing:border-box;z-index:5';
    const CENTER = 'position:absolute;left:32px;right:32px;top:50%;transform:translateY(-50%);background:#fff;border-radius:14px;padding:28px 24px 20px;display:flex;flex-direction:column;align-items:center;gap:10px;box-sizing:border-box;z-index:5';

    const btn = (label, kind) => ({ label,
      style: 'flex:' + (kind === 'wide' ? '1.4' : '1') + ';height:56px;border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:17px;font-weight:700;'
        + (kind === 'ghost' ? 'background:' + SEC + ';color:' + SUB + ';'
          : kind === 'danger' ? 'background:' + RED + ';color:#fff;'
            : kind === 'text' ? 'background:transparent;color:' + MUTED + ';'
              : 'background:' + P + ';color:#fff;') });

    const item = (label, kind) => ({ label,
      rowStyle: kind === 'act' || kind === 'actDanger'
        ? 'display:flex;align-items:center;gap:10px;min-height:56px;padding:0 2px;box-shadow:inset 0 -1px 0 ' + BORDER
        : 'display:flex;align-items:flex-start;gap:10px',
      mark: kind === 'del' ? 'width:5px;height:5px;flex:0 0 5px;margin-top:9px;border-radius:999px;background:' + RED
        : kind === 'keep' ? CHK(22, P, 'white')
          : kind === 'pick' ? 'width:22px;height:22px;flex:0 0 22px;border-radius:999px;box-shadow:inset 0 0 0 1.5px #dcdee3'
            : kind === 'act' || kind === 'actDanger' ? ''
              : 'width:5px;height:5px;flex:0 0 5px;margin-top:9px;border-radius:999px;background:' + P,
      textStyle: kind === 'act' ? 'flex:1;font-size:16px;font-weight:700;color:' + INK
        : kind === 'actDanger' ? 'flex:1;font-size:16px;font-weight:700;color:' + RED
          : 'flex:1;font-size:14px;line-height:21px;color:' + SUB });

    const sc = (o) => ({
      code: o.code, title: o.title, desc: o.desc,
      bgTitle: o.bgTitle, bgRows: o.bgRows,
      dimStyle: 'position:absolute;inset:0;background:' + (o.dim === 'none' ? 'transparent' : o.dim === 'light' ? 'rgba(0,0,0,.20)' : 'rgba(0,0,0,.45)') + ';z-index:4',
      isSheet: o.kind !== 'toast', isToast: o.kind === 'toast',
      grab: o.kind === 'sheet' || o.kind === 'action' ? true : '',
      icon: o.icon || '',
      iconStyle: o.icon === 'ok' ? CHK(48, '#e8faf6', '%231aa174')
        : o.icon === 'bad' ? BANG(48, '#ffe5e3', '%23e81607')
          : o.icon === 'warn' ? BANG(48, '#fff6e6', '%23805217') : '',
      sheetStyle: (o.kind === 'alert' || o.kind === 'confirm' || o.kind === 'danger' ? CENTER : SHEET),
      titleStyle: 'font-size:' + (o.kind === 'alert' || o.kind === 'confirm' || o.kind === 'danger' ? '20px;line-height:28px;text-align:center' : '22px;line-height:30px') + ';font-weight:700;color:' + INK + ';text-wrap:pretty',
      dTitle: o.dTitle, dBody: o.dBody || '',
      bodyStyle: 'font-size:14px;line-height:22px;color:' + MUTED + ';text-wrap:pretty;text-align:'
        + (o.kind === 'alert' || o.kind === 'confirm' || o.kind === 'danger' ? 'center' : 'left'),
      items: o.items || null,
      itemBox: o.kind === 'action' ? 'display:flex;flex-direction:column;align-self:stretch' : 'display:flex;flex-direction:column;gap:8px;padding:12px 16px;border-radius:10px;background:' + REC + ';align-self:stretch',
      btns: o.btns || null,
      btnRow: 'align-self:stretch;display:flex;gap:8px;padding-top:' + (o.kind === 'alert' || o.kind === 'confirm' || o.kind === 'danger' ? '14px' : '10px'),
      toastWrap: 'position:absolute;left:24px;right:24px;bottom:' + (o.toastLow ? '32px' : '100px') + ';display:flex;justify-content:center;z-index:6',
      toastStyle: 'max-width:100%;padding:14px 18px;border-radius:10px;background:rgba(23,25,28,.92);color:#fff;font-size:15px;line-height:22px;font-weight:700;display:inline-flex;align-items:center;gap:14px;box-shadow:0 4px 16px rgba(0,0,0,.24)',
      toastAct: o.toastAct || ''
    });

    const ty = (id, name, when, spec) => ({ id, name, when, spec });
    const sp = (k, v) => ({ k, v });
    const mx = (k, t, why, kind) => ({ k, t, why,
      tStyle: 'width:130px;flex:0 0 130px;font-size:13px;line-height:20px;font-weight:700;color:'
        + (kind === 'danger' ? RED : kind === 'toast' ? GREEN : kind === 'none' ? DIM : INK) });
    const wd = (ok, no, why) => ({ ok, no, why });
    const im = (k, v) => ({ k, v });

    return {
      cats: cats,
      allCats: allCats,
      rootStyle: 'display:flex;flex-direction:column;gap:52px;align-items:flex-start;padding:64px;width:max-content',
      Lcol: 'display:flex;flex-direction:column;gap:10px;width:390px',
      Leyebrow: 'font-size:14px;line-height:19px;font-weight:700;color:' + LC,
      Lh40: 'font-size:40px;line-height:52px;letter-spacing:-0.02em;font-weight:700;color:#212124',
      h26: 'font-size:26px;line-height:35px;letter-spacing:-0.02em;font-weight:700;color:#212124',
      Llead: 'font-size:18px;line-height:26px;color:#393a40;text-wrap:pretty',
      Ltag: 'min-height:26px;display:flex;align-items:center;flex-wrap:wrap;gap:6px 8px;font-size:18px;line-height:26px;font-weight:700;color:#212124',
      LtagId: 'width:26px;height:26px;flex:0 0 26px;border-radius:6px;background:#212124;color:#fff;display:inline-flex;align-items:center;justify-content:center;font-size:14px;font-weight:700',
      LtagIdWide: 'height:26px;flex:0 0 auto;padding:0 8px;border-radius:6px;background:#212124;color:#fff;display:inline-flex;align-items:center;justify-content:center;font-size:14px;font-weight:700',
      tagIdBrand: 'width:26px;height:26px;flex:0 0 26px;border-radius:6px;background:' + LC + ';color:#fff;display:inline-flex;align-items:center;justify-content:center;font-size:14px;font-weight:700',
      LtagDesc: 'height:63px;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;font-size:14px;line-height:21px;color:#4d5159;text-wrap:pretty',
      Lphone: 'width:390px;height:844px;border-radius:40px;overflow:hidden;position:relative;display:flex;flex-direction:column;background:#fff;box-shadow:0 15px 75px rgba(0,27,55,.14)',
      Lbar: 'height:44px;flex:0 0 44px;display:flex;align-items:center;justify-content:space-between;padding:0 26px;font-size:14px;font-weight:700;color:#212124',
      barIcons: 'display:flex;gap:5px;align-items:center',
      navBack: 'flex:0 0 56px;display:flex;align-items:center;gap:8px;padding:0 20px 0 12px;background:#fff',
      backBtn: 'width:40px;height:40px;flex:0 0 40px;border-radius:999px;display:flex;align-items:center;justify-content:center',
      navTitle: 'flex:1;min-width:0;font-size:18px;line-height:24px;font-weight:700;color:#212124',
      centerWrap: 'flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:32px;padding:0 24px',
      Ldock: 'flex:0 0 92px;background:#fff;box-shadow:inset 0 1px 0 #eaebee;padding:12px 24px;display:flex;box-sizing:border-box',
      ctaGhost: 'flex:1;height:52px;border:0;border-radius:6px;background:#f2f3f6;color:#393a40;font-family:inherit;font-size:18px;font-weight:700;cursor:pointer',

      orbitWrap: 'position:relative;width:120px;height:120px;flex:0 0 120px',
      orbitRing: 'position:absolute;inset:0;border-radius:999px;border:2px solid #f2f3f6',
      orbitSpin: 'position:absolute;inset:0;animation:wpOrbit 2400ms linear infinite',
      orbitDot: 'position:absolute;top:-5px;left:50%;margin-left:-5px;width:10px;height:10px;border-radius:999px;background:' + LC,

      textWrap: 'display:flex;flex-direction:column;align-items:center;gap:8px;text-align:center',
      h24: 'font-size:24px;line-height:32px;letter-spacing:-0.02em;font-weight:700;color:#212124',
      subLine: 'font-size:16px;line-height:24px;color:#868b94',
      stepList: 'display:flex;flex-direction:column;gap:4px;align-self:stretch;padding:0 24px',
      spinBig: 'width:40px;height:40px;border-radius:999px;border:3px solid #eaebee;border-top-color:' + LC + ';animation:wpSpin 900ms linear infinite',

      sheetCard: 'width:390px;background:#fff;border:1px solid #eaebee;border-radius:10px;padding:24px;display:flex;flex-direction:column;gap:20px;box-sizing:border-box',
      iconGrid: 'display:grid;grid-template-columns:repeat(4,1fr);gap:16px 8px',
      iconCell: 'display:flex;flex-direction:column;align-items:center;gap:8px;min-width:0',
      iconBox: 'width:56px;height:56px;border-radius:10px;background:#f7f8fa;display:flex;align-items:center;justify-content:center',
      iconLabel: 'font-size:14px;line-height:19px;font-weight:700;color:#4d5159;white-space:nowrap',
      specLabel: 'font-size:13px;line-height:18px;color:#adb1ba;font-variant-numeric:tabular-nums;white-space:nowrap',
      spinRow: 'display:flex;gap:24px;justify-content:center',
      spinCell: 'flex:1;min-width:0;border-radius:10px;background:#f7f8fa;padding:18px 12px;display:flex;flex-direction:column;align-items:center;gap:10px',
      arcRow: 'display:flex;align-items:center;gap:16px',
      arcSpin: 'animation:wpSpin 1400ms linear infinite',
      slowBox: 'width:64px;height:40px;flex:0 0 64px;border-radius:8px;background:#ffe8e4;color:#c2453a;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:700;font-variant-numeric:tabular-nums',
      Lhr: 'height:1px;background:#eaebee',
      hrThin: 'height:1px;background:#f2f3f6;margin:4px 0',
      noteTitle: 'font-size:16px;line-height:22px;font-weight:700;color:#212124',
      noteBody: 'font-size:15px;line-height:23px;color:#4d5159;text-wrap:pretty',

      skWrap: 'flex:1;padding:12px 24px;display:flex;flex-direction:column;gap:12px',
      skHero: 'height:168px;border-radius:10px;background:#eaebee;animation:wpSk 1400ms ease-in-out infinite',
      skWide: 'height:20px;width:62%;border-radius:4px;background:#eaebee;animation:wpSk 1400ms ease-in-out infinite',
      skNarrow: 'height:15px;width:38%;border-radius:4px;background:#f2f3f6;animation:wpSk 1400ms ease-in-out infinite',
      skRow: 'display:flex;gap:12px;align-items:center;padding:6px 0',
      skThumb: 'width:52px;height:52px;flex:0 0 52px;border-radius:6px;background:#eaebee;animation:wpSk 1400ms ease-in-out infinite',

      tableCard: 'width:1180px;background:#fff;border:1px solid #eaebee;border-radius:10px;padding:8px 24px 16px;display:flex;flex-direction:column;box-sizing:border-box',
      thead: 'display:flex;align-items:center;gap:16px;min-height:48px;box-shadow:inset 0 -1px 0 #dcdee3',
      tbody: 'display:flex;align-items:flex-start;gap:16px;min-height:56px;padding:14px 0;box-shadow:inset 0 -1px 0 #f2f3f6',
      th1: 'width:250px;flex:0 0 250px;font-size:14px;line-height:19px;font-weight:700;color:#868b94',
      th2: 'width:200px;flex:0 0 200px;font-size:14px;line-height:19px;font-weight:700;color:#868b94',
      th3: 'flex:1;font-size:14px;line-height:19px;font-weight:700;color:#868b94',
      td1: 'width:250px;flex:0 0 250px;font-size:16px;line-height:24px;font-weight:700;color:#212124;text-wrap:pretty',
      td3: 'flex:1;font-size:16px;line-height:24px;color:#4d5159;text-wrap:pretty',
      ruleCard: 'width:380px;background:#fff;border:1px solid #eaebee;border-radius:10px;padding:20px;display:flex;flex-direction:column;gap:8px;box-sizing:border-box',

      cats, allCats,

      steps: [
        step('스튜디오 취향 맞추기', 'done'),
        step('드레스 금액 비교', 'done'),
        step('메이크업 일정 확인', 'now'),
        step('헤어변형 후보 정리', 'wait'),
        step('본식스냅 · 부케 확인', 'wait'),
        step('청첩장 · 예물 정리', 'wait'),
        step('혼수 · 허니문 확인', 'wait')
      ],

      stepsOld: [
        step('웨딩홀 금액 비교', 'done'),
        step('스튜디오 취향 맞추기', 'now'),
        step('드레스 일정 확인', 'todo'),
        step('메이크업 후보 정리', 'todo')
      ],

      ocrSteps: [
        step('글자 읽기', 'done'),
        step('금액과 날짜 찾기', 'now'),
        step('업체 맞춰보기', 'todo')
      ],

      spinners: [
        spin(20, '작게', '20 · 버튼 · 행 안'),
        spin(28, '보통', '28 · 카드 · 시트'),
        spin(40, '크게', '40 · 화면 전체')
      ],

      skRows: [sk('72%', '46%'), sk('58%', '38%'), sk('66%', '42%')],

      usage: [
        use('추천 계산 · 첫 진입', '업종 순회 로딩', '두 분에게 맞는 곳을 찾고 있어요 · 10초 안에 끝나요', 'brand'),
        use('Pick 인증 자료 분석', '처리 중 · 단계 표시', '올려주신 자료를 읽고 있어요', 'brand'),
        use('검색 결과 · 목록', '목록 뼈대', '문구 없음', ''),
        use('업체 상세 첫 로딩', '목록 뼈대', '문구 없음', ''),
        use('버튼 눌러 저장 · 제출', '아이콘 순회 20', '버튼 안에서 라벨 대신', ''),
        use('당겨서 새로 고침', '아이콘 순회 20', '문구 없음', ''),
        use('응답이 700ms 초과', '아이콘 순회 28~40', '화면 성격과 무관하게 무조건', 'brand'),
        use('진행률을 아는 처리', '로더를 쓰지 않음', '진행바 + 퍼센트', 'no')
      ],

      Lrules: [
        { title: '원형 스피너를 쓰지 않아요', body: '로더는 업종 아이콘이 도는 것 하나뿐입니다. 크기만 20 · 28 · 40으로 바꿉니다. 호가 도는 원형 스피너를 새로 만들지 않습니다.' },
        { title: '700ms 넘으면 무조건 띄워요', body: '화면 성격과 무관하게 응답이 700ms를 넘으면 로더를 띄웁니다. 빈 화면이나 멈춘 화면을 보여주지 않습니다. 700ms 안에 오면 아무것도 띄우지 않습니다.' },
        { title: '목록에는 뼈대를 그려요', body: '목록이 들어올 자리에는 로더 대신 뼈대를 3줄까지 그립니다. 4줄 이상 그리면 실제 내용보다 뼈대가 더 오래 기억됩니다.' },
        { title: '예상 시간을 적어요', body: '사용자를 붙잡아두는 처리에는 «10초 안에 끝나요»처럼 예상 시간을 함께 씁니다. 없으면 얼마나 기다릴지 알 수 없습니다.' },
        { title: '가짜 진행률을 만들지 않아요', body: '실제 퍼센트를 모르면 아이콘 순회만 씁니다. 임의로 올라가는 진행바를 두지 않습니다.' },
        { title: '3초 넘으면 무엇을 하는지 말해요', body: '3초 안에 끝나면 로더만. 넘어가면 단계를 보여주고 끝난 단계는 체크로 바꿉니다.' }
      ],

      lroot: 'display:flex;flex-direction:column;gap:28px;align-items:flex-start;padding:64px;width:max-content',
      lintro: 'display:flex;flex-direction:column;gap:10px;max-width:760px;padding-bottom:4px',
      leyebrow: 'font-size:14px;line-height:19px;font-weight:700;color:' + C,
      h40: 'font-size:40px;line-height:52px;font-weight:700;color:#212124',
      llead: 'font-size:18px;line-height:26px;color:#393a40;text-wrap:pretty',

      lcard: 'width:760px;background:#fff;border-radius:12px;padding:28px;display:flex;flex-direction:column;gap:20px;box-sizing:border-box',
      specCard: 'width:760px;background:#fff;border-radius:12px;padding:28px;display:flex;flex-direction:column;gap:16px;box-sizing:border-box',
      cardTitle: 'font-size:18px;line-height:24px;font-weight:700;color:#212124',
      lrow: 'display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:20px',
      cell: 'display:flex;flex-direction:column;align-items:center;gap:6px;min-width:0',
      box: 'height:56px;display:flex;align-items:center;justify-content:center',
      label: 'font-size:15px;line-height:21px;font-weight:700;color:#212124;white-space:nowrap',
      spec: 'font-size:13px;line-height:18px;color:#868b94;font-variant-numeric:tabular-nums;white-space:nowrap',
      use: 'font-size:13px;line-height:18px;color:#adb1ba;white-space:nowrap',

      inlineBox: 'height:56px;display:flex;align-items:center;justify-content:center;gap:8px',
      inlineRing: ring(20, 2),
      inlineText: 'font-size:15px;line-height:21px;font-weight:700;color:#4d5159;white-space:nowrap',
      centerBox: 'height:56px;display:flex;align-items:center;justify-content:center',
      ringMd: ring(28, 2.5),
      fullBox: 'height:56px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px',
      ringLg: ring(32, 3),
      fullText: 'font-size:13px;line-height:18px;color:#868b94;white-space:nowrap',

      sizes: [
        { label: '작은 써클', spec: '20 · 두께 2', use: '버튼 · 행 안', ring: ring(20, 2) },
        { label: '보통 써클', spec: '28 · 두께 2.5', use: '카드 · 섹션', ring: ring(28, 2.5) },
        { label: '큰 써클', spec: '40 · 두께 3', use: '전체 화면', ring: ring(40, 3) }
      ],

      rows: 'display:flex;flex-direction:column;gap:2px',
      kvRow: 'display:flex;align-items:center;justify-content:space-between;gap:16px;min-height:48px;padding:10px 0',
      k: 'font-size:15px;line-height:21px;color:#4d5159;white-space:nowrap',
      v: 'font-size:15px;line-height:21px;font-weight:700;color:#212124;font-variant-numeric:tabular-nums;text-align:right',
      hr: 'height:1px;background:#eaebee',
      note: 'font-size:14px;line-height:21px;color:#868b94;text-wrap:pretty',

      table: [
        { k: '트랙', v: '#EAEBEE' },
        { k: '진행', v: '#FF6F61 · border-top-color' },
        { k: '두께', v: '20 → 2 · 28 → 2.5 · 40 → 3' },
        { k: '회전', v: '800ms linear infinite' },
        { k: '노출 임계', v: '700ms 초과' },
        { k: '인라인 gap', v: '8px' },
        { k: '영역 최소 높이', v: '120px' }
      ],
      eroot: 'display:flex;flex-direction:column;gap:32px;padding:64px;width:max-content',
      eintro: 'display:flex;flex-direction:column;gap:10px;max-width:1000px',
      eeyebrow: 'font-size:14px;line-height:19px;font-weight:700;color:' + eP,
      eh0: 'font-size:40px;line-height:52px;font-weight:700;color:' + eINK,
      elead: 'font-size:17px;line-height:26px;color:' + eSUB + ';text-wrap:pretty',
      erow: 'display:flex;gap:36px;align-items:flex-start;flex-wrap:wrap;max-width:1830px',
      ecol: 'display:flex;flex-direction:column;gap:10px;width:430px',
      ecolWide: 'display:flex;flex-direction:column;gap:10px;width:1100px',
      erow: 'display:flex;flex-wrap:wrap;gap:36px;align-items:flex-start',
      etag: 'height:26px;display:flex;align-items:center;gap:8px;white-space:nowrap',
      etag2: 'height:26px;margin-top:22px;display:flex;align-items:center;gap:8px;white-space:nowrap',
      etagText: 'font-size:18px;font-weight:700;color:' + eINK,
      etagId: 'height:26px;flex:0 0 auto;padding:0 8px;border-radius:6px;background:' + eP + ';color:#fff;display:inline-flex;align-items:center;font-size:12px;font-weight:700;white-space:nowrap',
      etagIdDark: 'height:26px;flex:0 0 auto;padding:0 8px;border-radius:6px;background:' + eINK + ';color:#fff;display:inline-flex;align-items:center;font-size:12px;font-weight:700;white-space:nowrap',
      etagDesc: 'height:66px;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;font-size:14px;line-height:21px;color:' + eSUB + ';text-wrap:pretty',

      ephone: 'width:430px;height:932px;border-radius:40px;overflow:hidden;position:relative;display:flex;flex-direction:column;background:#fff;box-shadow:0 15px 75px rgba(0,27,55,.14)',
      ebar: 'flex:0 0 44px;display:flex;align-items:center;padding:0 26px;font-size:14px;font-weight:700;color:' + eINK,
      navBar: 'flex:0 0 56px;display:flex;align-items:center;gap:8px;padding:0 16px;box-shadow:inset 0 -1px 0 #eaebee',
      navPad: 'width:36px;flex:0 0 36px',
      icoBack: eICO('chevron-left', 24, eINK) + ';width:36px;flex:0 0 36px;-webkit-mask-size:24px;mask-size:24px',
      icoChev: eICO('chevron-right', 14, eMUTED),
      scroll: 'flex:1;min-height:0;overflow-y:auto;display:flex;flex-direction:column;scrollbar-width:none',

      sec: 'flex:0 0 auto;padding:0 20px 24px;display:flex;flex-direction:column;gap:12px',
      secHead: 'display:flex;align-items:center;justify-content:space-between;gap:12px',
      secTitle: 'font-size:18px;font-weight:700;color:' + eINK,
      moreRow: 'display:inline-flex;align-items:center;gap:2px;font-size:13px;font-weight:700;color:' + eMUTED,
      emptyCard: 'border-radius:12px;background:' + eREC + ';padding:32px 20px;display:flex;flex-direction:column;align-items:center;gap:6px',
      emptyT: 'font-size:16px;font-weight:700;color:' + eINK + ';text-align:center',
      emptyS: 'font-size:13px;line-height:20px;color:' + eMUTED + ';text-align:center;text-wrap:pretty',
      rowsWrap: 'display:flex;flex-direction:column',
      dataRow: 'display:flex;align-items:center;justify-content:space-between;gap:12px;min-height:52px;box-shadow:inset 0 -1px 0 ' + eBORDER,
      dataK: 'font-size:15px;color:' + eSUB,
      dataV: 'font-size:15px;font-weight:700;color:' + eINK + ';font-variant-numeric:tabular-nums',

      doneWrap: 'flex:1;padding:72px 24px 24px;display:flex;flex-direction:column;align-items:center;gap:12px',
      doneTitle: 'font-size:26px;line-height:35px;font-weight:700;color:' + eINK + ';text-align:center;text-wrap:pretty;padding-top:6px',
      doneSub: 'font-size:15px;line-height:23px;color:' + eMUTED + ';text-align:center;text-wrap:pretty',
      itemBox: 'align-self:stretch;margin-top:12px;border-radius:12px;background:' + eREC + ';padding:18px;display:flex;flex-direction:column;gap:14px',
      itemRow: 'display:flex;align-items:flex-start;gap:10px',
      itemMark: eCHK(20, eP, 'white'),
      itemCol: 'flex:1;min-width:0;display:flex;flex-direction:column;gap:2px',
      itemK: 'font-size:13px;color:' + eMUTED,
      itemV: 'font-size:15px;font-weight:700;color:' + eINK,
      nextCard: 'align-self:stretch;margin-top:12px;border-radius:12px;background:#fff5f2;border:1px solid #ffd9d4;padding:18px;display:flex;flex-direction:column;gap:4px',
      nextLabel: 'font-size:12px;font-weight:700;color:' + eP,
      nextTitle: 'font-size:17px;font-weight:700;color:' + eINK,

      dock: 'flex:0 0 92px;padding:12px 20px;display:flex;gap:8px;box-shadow:inset 0 1px 0 ' + eBORDER,
      btnGhost: 'flex:1;height:56px;border-radius:6px;background:' + eSEC + ';color:' + eSUB + ';display:flex;align-items:center;justify-content:center;font-size:17px;font-weight:700',
      tabBar: 'flex:0 0 76px;display:flex;padding-top:8px;box-shadow:inset 0 1px 0 ' + eBORDER,
      tabCell: 'flex:1;display:flex;flex-direction:column;align-items:center;gap:4px',

      escreens: [
        esc({ code: 'WP-EMPTY-HOME', title: '홈 · 처음', tabs: 'home', nav: '웨딩픽', back: false,
          desc: '온보딩 직후. 추천은 나오지만 스케줄과 지출은 비어 있습니다. 각 섹션이 자기 빈 상태를 따로 가집니다.',
          sections: [
            empt('남은 스케줄', '아직 등록한 일정이 없어요', '첫 일정을 넣어보세요', '일정 넣기', '자세히'),
            empt('예산현황', '예산을 정하지 않았어요', '남은 금액을 알려드려요', '예산 정하기', '자세히')
          ] }),
        esc({ code: 'WP-EMPTY-PICK', title: 'Pick · 처음', tabs: 'pick', nav: 'Pick', back: false,
          desc: '담은 곳이 없을 때. 업종 목록을 보여주지 않고 추천으로 보냅니다. 처음 온 사람은 무엇을 찾을지 모릅니다.',
          sections: [
            empt('담은 곳', '아직 담은 곳이 없어요', '담아두면 여기서 비교할 수 있어요', '추천 보기')
          ] }),
        esc({ code: 'WP-EMPTY-NOTE', title: '웨딩노트 · 처음', tabs: 'note', nav: '웨딩노트', back: false,
          desc: '일정 · 예산 · 상담기록 세 탭이 모두 비어 있을 때. 세 개를 한 화면에 나열하지 않고 가장 먼저 할 것만 크게 둡니다.',
          sections: [
            empt('일정', '예식일만 넣어두면 나머지는 알려드려요', '준비 순서를 차례대로 챙겨드려요', '예식일 확인하기'),
            data('예산', [{ k: '총예산', v: '1,750만원' }, { k: '쓴 금액', v: '0원' }])
          ] }),
        esc({ code: 'WP-EMPTY-LNG', title: '라운지 · 처음', nav: '라운지',
          desc: '후기와 박람회가 아직 적을 때. 「없어요」로 끝내지 않고 첫 글을 쓰게 합니다. Pick 인증을 한 사람만 후기를 쓸 수 있어 조건도 함께 적습니다.',
          sections: [
            empt('후기', '이 지역 첫 후기를 남겨보세요', 'Pick 인증을 하면 후기를 쓸 수 있어요', 'Pick 인증하기'),
            empt('박람회', '예정된 박람회가 없어요', '새 일정이 올라오면 알려드릴게요', '알림 받기')
          ] }),
        esc({ code: 'WP-EMPTY-REC', title: '추천 · 조건 부족', nav: '웨딩픽 추천',
          desc: '지역이나 스타일을 건너뛴 사용자. 추천을 만들 근거가 없으면 억지로 만들지 않고 무엇을 채우면 되는지 말합니다.',
          sections: [
            empt('검색', '조건을 조금만 더 알려주세요', '지역을 정하면 맞는 곳을 보여드려요', '지역 정하기')
          ] }),
        esc({ code: 'WP-DONE-RPT', title: 'Pick 인증 완료', back: false,
          desc: '완료 화면. back을 두지 않고 어디에 반영됐는지 항목으로 보여준 뒤 다음 할 일로 보냅니다.',
          mark: 'ok', doneT: '인증이 반영됐어요', doneS: '강남 A 스튜디오 금액 구간에 들어갔어요',
          items: [
            { k: '실 제보', v: '12건 → 13건' },
            { k: '예산현황', v: '168만원이 들어갔어요' },
            { k: '내 상태', v: 'Pick 인증 회원이 됐어요' }
          ],
          nextCard: '후기를 남기면 다음 사람에게 도움이 돼요',
          dock: '후기 쓰기', dock2: '홈으로' }),
        esc({ code: 'WP-DONE-VEND', title: '상담 예약 완료', back: false,
          desc: '예약이 끝난 뒤. 웨딩노트에 자동으로 들어간 것을 보여주고, 상담 전에 준비할 것을 한 줄로 알립니다.',
          doneT: '9월 20일 오후 2시로 잡았어요', doneS: '강남 A 스튜디오 · 김소연 작가',
          items: [
            { k: '웨딩노트', v: '일정에 들어갔어요' },
            { k: '알림', v: '하루 전과 두 시간 전에 알려드려요' },
            { k: '준호님', v: '이 일정이 보여요' }
          ],
          nextCard: '원하는 분위기 사진을 모아두면 좋아요',
          dock: '웨딩노트 보기', dock2: '홈으로' })
      ],

      ecard: 'width:1100px;background:#fff;border:1px solid ' + eBORDER + ';border-radius:10px;padding:8px 24px 16px;display:flex;flex-direction:column;box-sizing:border-box',
      rRow: 'display:flex;align-items:flex-start;gap:16px;min-height:48px;padding:11px 0;box-shadow:inset 0 -1px 0 ' + eSEC,
      rK: 'width:220px;flex:0 0 220px;font-size:13px;line-height:20px;font-weight:700;color:' + eINK,
      rV: 'flex:1;font-size:13px;line-height:20px;color:' + eSUB + ';text-wrap:pretty',
      rules: [
        rl('섹션마다 따로', '화면 전체를 비우지 않고 섹션별로 빈 상태를 둔다. 홈은 추천은 나오고 스케줄만 비어 있을 수 있다'),
        rl('행동 하나만', '빈 상태에 버튼은 하나다. 두 개를 두면 무엇부터 할지 또 고민한다'),
        rl('조건을 함께', '할 수 없는 일이면 조건을 적는다 — 「Pick 인증을 하면 후기를 쓸 수 있어요」'),
        rl('이모지 · 일러스트 없음', '아이콘도 두지 않는다. 제목 · 설명 · 버튼 세 줄로 끝낸다'),
        rl('안내는 한 줄', '설명 문구는 한 줄을 넘기지 않는다. 두 줄이 되면 문장을 줄인다'),
        rl('문의를 권하지 않음', '«알려주세요» «문의해주세요»로 사용자에게 일을 넘기지 않는다'),
        rl('근거 없으면 만들지 않음', '추천할 근거가 없으면 무엇을 채우면 되는지 말한다. 아무거나 보여주지 않는다'),
        rl('완료 화면 back 없음', '결정 · 인증 · 연결 · 예약 완료는 back을 두지 않는다. 물리 back은 CTA와 같은 곳으로'),
        rl('완료는 반영 결과를 보여줌', '무엇이 어디에 들어갔는지 항목으로 적는다. 「완료됐습니다」만 두지 않는다'),
        rl('완료 다음 행동', '주 CTA는 반영된 곳으로 · 보조는 홈으로. 다음에 할 일이 있으면 카드로 권한다'),
        rl('빈 카드는 빈 상태에만', '회색 중앙정렬 카드는 데이터가 없을 때만 쓴다. 실제 목록은 썸네일 행으로 그린다'),
        rl('0건과 0원은 다름', '데이터가 없으면 빈 상태 · 값이 0이면 숫자를 보여준다. 쓴 금액 0원은 정상 상태'),
        rl('알림 받기', '나중에 생기는 것은 알림을 권한다 — 박람회 · 새 업체'),
        rl('첫 사람 유도', '후기처럼 사용자가 만드는 것은 「첫 후기를 남겨보세요」로 권한다')
      ],

      ewHead: 'display:flex;align-items:center;gap:16px;min-height:44px;box-shadow:inset 0 -1px 0 #dcdee3',
      ewRow: 'display:flex;align-items:flex-start;gap:16px;min-height:48px;padding:11px 0;box-shadow:inset 0 -1px 0 ' + eSEC,
      ewh1: 'width:150px;flex:0 0 150px;font-size:12px;font-weight:700;color:' + eMUTED,
      ewh2: 'width:330px;flex:0 0 330px;font-size:12px;font-weight:700;color:' + eMUTED,
      ewh3: 'flex:1;font-size:12px;font-weight:700;color:' + eMUTED,
      ewc1: 'width:150px;flex:0 0 150px;font-size:13px;line-height:20px;font-weight:700;color:' + eINK,
      ewc2: 'width:330px;flex:0 0 330px;font-size:13px;line-height:20px;font-weight:700;color:' + eINK,
      ewc3: 'flex:1;font-size:12px;line-height:19px;color:' + eMUTED + ';text-wrap:pretty',
      copies: [
        cp('홈 · 스케줄', '아직 등록한 일정이 없어요', '첫 일정을 넣어보세요 · [일정 넣기]'),
        cp('홈 · 예산', '예산을 정하지 않았어요', '남은 금액을 알려드려요 · [예산 정하기]'),
        cp('Pick', '아직 담은 곳이 없어요', '담아두면 여기서 비교할 수 있어요 · [추천 보기]'),
        cp('웨딩노트 · 일정', '예식일만 넣어두면 나머지는 알려드려요', '준비 순서를 차례대로 챙겨드려요 · [예식일 확인하기]'),
        cp('라운지 · 후기', '이 지역 첫 후기를 남겨보세요', 'Pick 인증을 하면 쓸 수 있어요 · [Pick 인증하기]'),
        cp('라운지 · 박람회', '예정된 박람회가 없어요', '새 일정이 올라오면 알려드릴게요 · [알림 받기]'),
        cp('검색 · 조건 부족', '조건을 조금만 더 알려주세요', '지역을 정하면 맞는 곳을 보여드려요 · [지역 정하기]'),
        cp('검색 · 결과 0', '조건에 맞는 곳이 없어요', '예산을 풀면 11곳을 볼 수 있어요 · [예산 조건 풀기]'),
        cp('스크랩', '아직 스크랩한 글이 없어요', '마음에 드는 글을 저장해보세요 · [라운지 보기]'),
        cp('내 후기', '아직 쓴 후기가 없어요', 'Pick 인증을 한 곳에 쓸 수 있어요 · [쓸 수 있는 곳 보기]'),
        cp('알림', '새 소식이 없어요', '일정과 Pick 변화를 알려드려요'),
        cp('문의 내역', '문의한 내역이 없어요', '무엇이든 편하게 남겨주세요 · [문의하기]')
      ],
      root: 'display:flex;flex-direction:column;gap:32px;padding:64px;width:max-content',
      intro: 'display:flex;flex-direction:column;gap:10px;max-width:1000px',
      eyebrow: 'font-size:14px;line-height:19px;font-weight:700;color:' + P,
      h0: 'font-size:40px;line-height:52px;font-weight:700;color:' + INK,
      lead: 'font-size:17px;line-height:26px;color:' + SUB + ';text-wrap:pretty',
      row: 'display:flex;gap:36px;align-items:flex-start;flex-wrap:wrap;max-width:1830px',
      col: 'display:flex;flex-direction:column;gap:10px;width:430px',
      colWide: 'display:flex;flex-direction:column;gap:10px;width:1100px',
      tag: 'height:26px;display:flex;align-items:center;gap:8px;white-space:nowrap',
      tag2: 'height:26px;margin-top:22px;display:flex;align-items:center;gap:8px;white-space:nowrap',
      tagText: 'font-size:18px;font-weight:700;color:' + INK,
      tagId: 'height:26px;flex:0 0 auto;padding:0 8px;border-radius:6px;background:' + P + ';color:#fff;display:inline-flex;align-items:center;font-size:12px;font-weight:700;white-space:nowrap;font-variant-numeric:tabular-nums',
      tagIdDark: 'height:26px;flex:0 0 auto;padding:0 8px;border-radius:6px;background:' + INK + ';color:#fff;display:inline-flex;align-items:center;font-size:12px;font-weight:700;white-space:nowrap',
      tagDesc: 'height:66px;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;font-size:14px;line-height:21px;color:' + SUB + ';text-wrap:pretty',

      typeRow: 'display:flex;gap:20px;flex-wrap:wrap;max-width:1830px',
      typeCard: 'width:290px;background:#fff;border:1px solid ' + BORDER + ';border-radius:10px;padding:18px;display:flex;flex-direction:column;gap:10px;box-sizing:border-box',
      typeHead: 'display:flex;align-items:center;gap:8px',
      typeId: 'height:24px;padding:0 8px;border-radius:5px;background:' + INK + ';color:#fff;display:inline-flex;align-items:center;font-size:11px;font-weight:700;white-space:nowrap',
      typeName: 'font-size:16px;font-weight:700;color:' + INK,
      typeWhen: 'font-size:13px;line-height:20px;color:' + MUTED + ';text-wrap:pretty;min-height:40px',
      typeSpecWrap: 'display:flex;flex-direction:column;gap:5px;padding-top:2px',
      specRow: 'display:flex;gap:10px',
      specK: 'width:58px;flex:0 0 58px;font-size:12px;color:' + DIM,
      specV: 'flex:1;font-size:12px;line-height:18px;color:' + SUB + ';font-variant-numeric:tabular-nums',
      types: [
        ty('WP-DLG-A', '알림', '알려주기만 하면 될 때. 사용자가 고를 것이 없습니다.', [
          sp('배치', '중앙 · 좌우 32'), sp('버튼', '1개 · 확인'), sp('배경', 'rgba(0,0,0,.45)'), sp('닫기', '버튼 · 배경 탭')]),
        ty('WP-DLG-B', '확인', '되돌릴 수 있는 일을 물어볼 때.', [
          sp('배치', '중앙 · 좌우 32'), sp('버튼', '2개 · 취소 + 실행'), sp('배경', 'rgba(0,0,0,.45)'), sp('닫기', '취소 · 배경 탭')]),
        ty('WP-DLG-C', '되돌릴 수 없음', '지우거나 끊는 일. 영향 범위를 항목으로 보여줍니다.', [
          sp('배치', '중앙 · 좌우 32'), sp('버튼', '2개 · 취소 + 빨강'), sp('배경', 'rgba(0,0,0,.45)'), sp('닫기', '취소만 · 배경 탭 안 됨')]),
        ty('WP-DLG-D', '바텀시트', '고르거나 입력할 것이 있을 때. 보던 화면을 남깁니다.', [
          sp('배치', '하단 · r20 상단만'), sp('버튼', '1~2개 · 56px'), sp('배경', 'rgba(0,0,0,.45)'), sp('닫기', '드래그 · 배경 탭 · X')]),
        ty('WP-DLG-E', '행동 목록', '같은 대상에 여러 동작이 있을 때.', [
          sp('배치', '하단 · 행 56px'), sp('버튼', '목록 + 취소'), sp('배경', 'rgba(0,0,0,.45)'), sp('닫기', '취소 · 배경 탭')]),
        ty('WP-DLG-F', '토스트', '결과만 알릴 때. 막지 않습니다.', [
          sp('배치', 'dock 위 100 · 없으면 32'), sp('버튼', '없음 또는 실행취소'), sp('배경', '없음'), sp('닫기', '2초 후 자동')])
      ],

      phone: 'width:430px;height:600px;border-radius:32px;overflow:hidden;position:relative;display:flex;flex-direction:column;background:#fff;box-shadow:0 15px 75px rgba(0,27,55,.14)',
      bar: 'flex:0 0 44px;display:flex;align-items:center;padding:0 26px;font-size:14px;font-weight:700;color:' + INK,
      bgWrap: 'flex:1;display:flex;flex-direction:column;overflow:hidden',
      bgHead: 'flex:0 0 52px;display:flex;align-items:center;padding:0 20px;box-shadow:inset 0 -1px 0 ' + BORDER,
      bgTitle: 'font-size:18px;font-weight:700;color:' + INK,
      bgBody: 'flex:1;padding:8px 20px;display:flex;flex-direction:column',
      bgRow: 'display:flex;align-items:center;min-height:52px;box-shadow:inset 0 -1px 0 ' + BORDER,
      bgRowT: 'font-size:15px;color:' + MUTED,

      grab: 'align-self:center;width:40px;height:4px;border-radius:999px;background:' + BORDER + ';margin-bottom:4px',
      dBody: 'font-size:14px;line-height:22px;color:' + MUTED + ';text-wrap:pretty;text-align:inherit',
      itemWrap: 'display:flex;flex-direction:column;gap:8px;padding:12px 16px;border-radius:10px;background:' + REC + ';align-self:stretch',
      toastAct: 'font-size:14px;font-weight:700;color:#ffb3ab;white-space:nowrap',

      screens: [
        sc({ code: 'WP-DLG-A', title: '알림', kind: 'alert', dim: 'full',
          desc: '고를 것이 없습니다. 버튼 하나로 닫습니다. 이 유형에 취소 버튼을 넣지 않습니다.',
          bgTitle: 'Pick 인증', bgRows: ['낸 금액 · 168만원', '낸 날짜 · 8월 28일', '업체 · 강남 A 스튜디오'],
          icon: 'ok', dTitle: '인증이 반영됐어요',
          dBody: '강남 A 스튜디오 금액 구간에 들어갔어요.',
          btns: [btn('확인')] }),
        sc({ code: 'WP-DLG-B', title: '확인', kind: 'confirm', dim: 'full',
          desc: '되돌릴 수 있는 일입니다. 오른쪽이 실행, 왼쪽이 취소입니다. 순서를 바꾸지 않습니다.',
          bgTitle: 'Pick', bgRows: ['강남 A 스튜디오', '서촌 B 스튜디오', '청담 C 스튜디오'],
          dTitle: '후보에서 뺄까요?',
          dBody: '준호님 목록에서도 함께 사라져요. 다시 담을 수 있어요.',
          btns: [btn('그대로 둘게요', 'ghost'), btn('빼기')] }),
        sc({ code: 'WP-DLG-C', title: '되돌릴 수 없음', kind: 'danger', dim: 'full',
          desc: '무엇이 사라지는지 항목으로 먼저 보여줍니다. 배경 탭으로 닫히지 않습니다. 실행 버튼만 빨강입니다.',
          bgTitle: '연결관리', bgRows: ['준호님과 함께 준비 중', '같이 보는 것 4개', '변경 내역 보기'],
          icon: 'bad', dTitle: '연결을 끊을까요?',
          items: [item('같이 보던 일정과 지출이 각자에게만 남아요', 'del'), item('함께 쓴 메모는 각자 사본으로 남아요', 'del'), item('준호님에게 알림이 가요', 'del')],
          btns: [btn('그대로 둘게요', 'ghost'), btn('연결 끊기', 'danger')] }),
        sc({ code: 'WP-DLG-D', title: '바텀시트', kind: 'sheet', dim: 'full',
          desc: '고르거나 입력할 것이 있을 때. 보던 화면을 위에 남겨 맥락을 잃지 않게 합니다. 제목은 왼쪽 정렬입니다.',
          bgTitle: '업체 상세', bgRows: ['152~184만원', '실 제보 12건', '추천 이유 3개'],
          dTitle: '비교할 곳을 골라주세요',
          dBody: '같은 업종에서 2~3곳까지 담을 수 있어요.',
          items: [item('강남 A 스튜디오 · 152~184만원', 'keep'), item('서촌 B 스튜디오 · 138~171만원', 'keep'), item('청담 C 스튜디오 · 165~203만원', 'pick')],
          btns: [btn('2곳 비교하기')] }),
        sc({ code: 'WP-DLG-E', title: '행동 목록', kind: 'action', dim: 'full',
          desc: '같은 대상에 여러 동작이 있을 때. 위험한 동작은 맨 아래에 빨간 글자로 둡니다. 취소는 목록과 떨어뜨립니다.',
          bgTitle: '후기', bgRows: ['김OO · 2026.07', '진행 · 빨랐어요', '도움돼요 14'],
          dTitle: '이 후기로 무엇을 할까요?',
          items: [item('도움돼요 누르기', 'act'), item('링크 복사', 'act'), item('신고하기', 'actDanger')],
          btns: [btn('취소', 'ghost')] }),
        sc({ code: 'WP-DLG-F', title: '토스트', kind: 'toast', dim: 'none',
          desc: '결과만 알립니다. 화면을 막지 않고 2초 후 사라집니다. 실행취소가 가능한 동작에만 버튼을 붙입니다.',
          bgTitle: 'Pick', bgRows: ['강남 A 스튜디오', '서촌 B 스튜디오', '청담 C 스튜디오'],
          dTitle: '후보에서 뺐어요', toastAct: '되돌리기' }),
        sc({ code: 'WP-DLG-F', title: '토스트 · 제한 안내', kind: 'toast', dim: 'none', toastLow: true,
          desc: '할 수 없는 동작을 눌렀을 때. 이유만 짧게 말하고 버튼을 두지 않습니다. 시트를 띄우지 않습니다.',
          bgTitle: '스타일', bgRows: ['도시적인 · 선택', '자연스러운 · 선택', '로맨틱한'],
          dTitle: '스타일은 2개까지 고를 수 있어요' }),
        sc({ code: 'WP-DLG-B', title: '확인 · 작성 중 이탈', kind: 'confirm', dim: 'full',
          desc: '입력한 것이 있을 때만 묻습니다. 비어 있으면 묻지 않고 바로 나갑니다.',
          bgTitle: '후기 작성', bgRows: ['진행 · 빨랐어요', '결과물 · 기대 이상', '본문 · 작성 중'],
          icon: 'warn', dTitle: '작성을 그만둘까요?',
          dBody: '쓰던 내용은 저장되지 않아요.',
          btns: [btn('이어서 쓰기', 'ghost'), btn('그만두기')] })
      ],

      card: 'width:1100px;background:#fff;border:1px solid ' + BORDER + ';border-radius:10px;padding:8px 24px 16px;display:flex;flex-direction:column;box-sizing:border-box',
      mHead: 'display:flex;align-items:center;gap:16px;min-height:44px;box-shadow:inset 0 -1px 0 #dcdee3',
      mRow: 'display:flex;align-items:flex-start;gap:16px;min-height:48px;padding:11px 0;box-shadow:inset 0 -1px 0 ' + SEC,
      mh1: 'width:300px;flex:0 0 300px;font-size:12px;font-weight:700;color:' + MUTED,
      mh2: 'width:130px;flex:0 0 130px;font-size:12px;font-weight:700;color:' + MUTED,
      mh3: 'flex:1;font-size:12px;font-weight:700;color:' + MUTED,
      mc1: 'width:300px;flex:0 0 300px;font-size:13px;line-height:20px;font-weight:700;color:' + INK + ';text-wrap:pretty',
      mc3: 'flex:1;font-size:12px;line-height:19px;color:' + MUTED + ';text-wrap:pretty',
      matrix: [
        mx('Pick 인증이 반영됐어요', 'A 알림', '고를 것이 없고 결과만 알린다'),
        mx('후보에서 빼기', 'B 확인', '되돌릴 수 있지만 배우자에게도 영향이 간다'),
        mx('최종 결정하기', 'B 확인', '되돌릴 수 있다 · 무엇이 반영되는지 적는다'),
        mx('연결 끊기', 'C 되돌릴 수 없음', '공유가 끝나고 상대에게 알림이 간다', 'danger'),
        mx('회원 탈퇴', 'C 되돌릴 수 없음', '계정이 사라진다 · 영향 항목 필수', 'danger'),
        mx('후기 신고', 'C 되돌릴 수 없음', '접수되면 취소할 수 없다', 'danger'),
        mx('비교할 곳 고르기', 'D 바텀시트', '여러 개를 고른다'),
        mx('필터 · 정렬', 'D 바텀시트', '고를 것이 많다'),
        mx('예식일 · 지역 고르기', 'D 바텀시트', '휠을 굴린다'),
        mx('달력에 일정 넣기', 'D 바텀시트', '어느 캘린더인지 고른다'),
        mx('후기 · 업체에 여러 동작', 'E 행동 목록', '대상 하나에 동작이 3개 이상이다'),
        mx('후보에서 뺐어요', 'F 토스트', '되돌릴 수 있어 버튼을 붙인다', 'toast'),
        mx('스타일 3개째 선택', 'F 토스트', '막힌 이유만 알린다', 'toast'),
        mx('링크를 복사했어요', 'F 토스트', '결과만 알린다', 'toast'),
        mx('작성 중 나가기 · 내용 있음', 'B 확인', '쓴 것이 사라진다'),
        mx('작성 중 나가기 · 내용 없음', '없음', '잃을 것이 없으면 묻지 않는다', 'none'),
        mx('저장 성공', '없음', '화면이 바뀌면 그것이 답이다', 'none'),
        mx('네트워크 오류', 'A 알림', '무엇을 하면 되는지 적는다')
      ],

      wHead: 'display:flex;align-items:center;gap:16px;min-height:44px;box-shadow:inset 0 -1px 0 #dcdee3',
      wRow: 'display:flex;align-items:flex-start;gap:16px;min-height:48px;padding:11px 0;box-shadow:inset 0 -1px 0 ' + SEC,
      wh1: 'width:300px;flex:0 0 300px;font-size:12px;font-weight:700;color:' + MUTED,
      wh2: 'width:300px;flex:0 0 300px;font-size:12px;font-weight:700;color:' + MUTED,
      wh3: 'flex:1;font-size:12px;font-weight:700;color:' + MUTED,
      wc1: 'width:300px;flex:0 0 300px;font-size:13px;line-height:20px;font-weight:700;color:' + INK,
      wc2: 'width:300px;flex:0 0 300px;font-size:13px;line-height:20px;color:' + MUTED,
      wc3: 'flex:1;font-size:12px;line-height:19px;color:' + MUTED,
      words: [
        wd('후보에서 뺄까요?', '정말 삭제하시겠습니까?', '무엇이 일어나는지 말한다'),
        wd('연결을 끊을까요?', '연결 해제를 진행하시겠습니까?', '한자어를 쓰지 않는다'),
        wd('그대로 둘게요', '취소', '취소가 무엇을 취소하는지 모른다'),
        wd('빼기 · 연결 끊기 · 그만두기', '확인 · 예', '버튼이 할 일을 그대로 적는다'),
        wd('이어서 쓰기', '아니오', '두 버튼이 같은 문장으로 읽혀야 한다'),
        wd('쓰던 내용은 저장되지 않아요', '변경사항이 유실됩니다', '사용자 말로 적는다'),
        wd('스타일은 2개까지 고를 수 있어요', '최대 선택 개수를 초과했습니다', '제한을 사실로 말한다'),
        wd('다시 시도', '재시도', '줄임말을 쓰지 않는다'),
        wd('잠시 문제가 생겼어요', '오류가 발생했습니다 (500)', '코드를 보여주지 않는다'),
        wd('확인하는 데 시간이 걸려요', '검증 대기 중입니다', '운영자 용어를 쓰지 않는다'),
        wd('되돌리기', '실행 취소', '토스트는 짧게'),
        wd('제목 1줄 · 본문 2줄', '제목 2줄 이상', '읽는 데 3초를 넘기지 않는다')
      ],

      iRow: 'display:flex;align-items:flex-start;gap:16px;min-height:48px;padding:11px 0;box-shadow:inset 0 -1px 0 ' + SEC,
      iK: 'width:200px;flex:0 0 200px;font-size:13px;line-height:20px;font-weight:700;color:' + INK,
      iV: 'flex:1;font-size:13px;line-height:20px;color:' + SUB + ';text-wrap:pretty',
      impl: [
        im('브라우저 API 금지', 'alert · confirm · prompt를 쓰지 않는다. 여섯 유형만 쓴다'),
        im('한 번에 하나', '다이얼로그를 겹쳐 띄우지 않는다. 열려 있으면 뒤 것을 큐에 넣는다'),
        im('버튼 순서', '왼쪽이 취소 · 오른쪽이 실행. 순서를 바꾸지 않는다'),
        im('실행 버튼 색', '기본 코랄 · 되돌릴 수 없는 것만 빨강 #FF4133'),
        im('배경 탭', 'A · B · D · E는 닫힌다. C는 닫히지 않는다'),
        im('안드로이드 back', '다이얼로그만 닫고 화면은 그대로. C는 취소와 같다'),
        im('토스트 위치', 'dock 있으면 그 위 100px · 없으면 하단 32px'),
        im('토스트 시간', '2초 · 되돌리기가 있으면 4초. 연속 발생 시 최신 하나만'),
        im('진입 모션', '시트 350ms cubic-bezier(.16,1,.3,1) · 중앙 200ms 페이드 + scale(.96→1)'),
        im('포커스', '열릴 때 다이얼로그로 · 닫힐 때 호출한 요소로 되돌린다'),
        im('제목 없는 다이얼로그', '만들지 않는다. 제목 한 줄은 필수'),
        im('성공 알림', '화면이 바뀌면 띄우지 않는다. 같은 화면에 남을 때만 토스트')
      ]
    };
  }
}


export default Component;
